// _____________________________________________________________________________________________________ //

import mysql from "mysql2"              // (cmengambil library dari MySQL2)


const db = mysql.createConnection({     // [kabel penghubung antara backend dan MySQL]
    host: "localhost",
    user: "root",
    password: "Okkotsu#354",
    database: "db_siswaujk"
});


 db.connect((err) => {                  // (tes koneksi ke mysql workbench nya)
    if (err) {
        console.log("connection failed ❌:", err);  // Untuk debugging kalau database tidak terhubung
        return;
    }
        console.log("connection connected to workbench ✔️"); // Untuk memastikan koneksi berhasil
 });

 export default db;                     // (mengexpor koneksi agar file lain bisa pake koneksi yg smaa)

 // _____________________________________________________________________________________________________ //