/*untuk membuat database dan tabel siswa sebagai tempat penyimpanan data utama aplikasi CRUD

CREATE DATABASE if not exists db_siswaujk;

use db_siswaujk;

CREATE TABLE DATA_SISWA (
		kode_siswa INT PRIMARY KEY auto_increment,
        nama_siswa VARCHAR(100) NOT NULL,
        alamat_siswa VARCHAR(150) NOT NULL,
        tgl_siswa DATE NOT NULL,
        jurusan_siswa ENUM('RPL', 'TKJ') NOT NULL
) 