// _____________________________________________________________________________________________________________________________________________________ //
// berfungsi untuk menjalankan server Express, mengatur middleware, dan menghubungkan semua routing aplikasi
// Express mempermudah pembuatan REST API di Node.js

import express from "express";  // (mengambil semua data yang di butuhkan (framework express & middleware cors) & file routing endpoint resource si34iwa)
import cors from "cors";
import siswaRoutes from "./routes/siswaRoutes.js";





const app = express();          // (membuat instance express atau aplikasi untuk menampung route & middleware)

app.use(cors());                // (masang middleware CORS secara global untuk membatasi asal)
app.use(express.json());        // (middleware bawaan express buat parsing JSON body drari request)
app.use("/siswa", siswaRoutes);

app.listen(3000, () => {        // (menjalankan server diport 2004, & ngasih tau kalo server berjalan)
    console.log("server running on 🚀 - http://localhost:3000");
});

// _____________________________________________________________________________________________________________________________________________________ //
