
// Request → Middleware → Controller → Database
// berfungsi sebagai middleware untuk memvalidasi data siswa sebelum data diproses oleh controlle

export const ValidateCreateSiswa = (req, res, next) => {
  const { nama_siswa, alamat_siswa, tgl_siswa, jurusan_siswa } = req.body;
  const errors = [];      // Agar user tahu semua kesalahan sekaligus.          
                                        // Ambil body → cek kosong → kumpulkan error → lolos → next()
  if (!nama_siswa)
    errors.push("Nama siswa wajib dicantumkan!");

  if (!alamat_siswa)
    errors.push("Alamat siswa wajib dicantumkan!");

  if (!tgl_siswa)
    errors.push("Tanggal lahir wajib dicantumkan!");

  if (!jurusan_siswa)
    errors.push("Jurusan wajib dicantumkan!");

  if (errors.length)
    return res.status(400).json({ errors });

  next();       // next() menandakan validasi lolos
};

export const ValidateUpdateSiswa = (req, res, next) => {
  const { nama_siswa, alamat_siswa, tgl_siswa, jurusan_siswa } = req.body;
  const errors = [];

  if (nama_siswa !== undefined && !nama_siswa)
    errors.push("Nama siswa wajib diisi");

  if (alamat_siswa !== undefined && !alamat_siswa)
    errors.push("Alamat siswa wajib diisi");

  if (tgl_siswa !== undefined && isNaN(Date.parse(tgl_siswa)))
    errors.push("Format tanggal lahir tidak valid");

  if (jurusan_siswa !== undefined && !jurusan_siswa)
    errors.push("Jurusan wajib diisi");

  if (errors.length)
    return res.status(400).json({ errors });

  next();
};
