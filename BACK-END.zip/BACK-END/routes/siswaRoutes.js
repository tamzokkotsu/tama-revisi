import express from "express";
import {
  ValidateCreateSiswa,
  ValidateUpdateSiswa
} from "../middleware/validation.js";

import {
  getSiswa,
  getSiswaByKode,
  insertSiswa,
  updateSiswa,
  deleteSiswa
} from "../controllers/siswaController.js";

const router = express.Router();

router.get("/", getSiswa);
router.get("/:kode_siswa", getSiswaByKode);
router.post("/", ValidateCreateSiswa, insertSiswa);
router.put("/:kode_siswa", ValidateUpdateSiswa, updateSiswa);
router.delete("/:kode_siswa", deleteSiswa);

export default router;