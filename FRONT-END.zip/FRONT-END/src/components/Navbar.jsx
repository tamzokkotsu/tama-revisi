import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <div style={{
        padding: '10px',
        paddingTop: '25px',
    }}>
    <nav className="navbar navbar-expand-lg navbar-dark rounded-4 pt-3 pe-1 pb-2" style={{ 
        backgroundColor: '#ebae3dff', 
        }}>
      <div className="container-fluid">

        <Link className="navbar-brand ms-2" style={{fontFamily:'roboto', color:'#fff9c5ff'}} to="/">SHIBUYA SCHOOL</Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNavAltMarkup"
          aria-controls="navbarNavAltMarkup"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

      </div>
    </nav>
    </div>
  );
}