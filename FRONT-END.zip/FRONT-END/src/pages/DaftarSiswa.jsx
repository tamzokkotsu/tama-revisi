
import axios from "axios";
import { useEffect, useState } from "react";
import { FaEdit, FaRegTrashAlt } from "react-icons/fa";

const API = "http://localhost:3000/siswa";

export default function DaftarSiswa() {
  const [siswa, setSiswa] = useState([]);
  const [loading, setLoading] = useState(false);

  const [kodeSiswa, setKodeSiswa] = useState("");
  const [nama, setNama] = useState("");
  const [alamat, setAlamat] = useState("");
  const [tgl, setTgl] = useState("");
  const [jurusan, setJurusan] = useState("");

  const [editingKode, setEditingKode] = useState(null);

  const fetchSiswa = async () => {
    try {
      setLoading(true);
      const res = await axios.get(API);
      setSiswa(res.data);
    } catch (err) {
      console.error(err);
      alert("Gagal mengambil data siswa. Cek backend berjalan di http://localhost:3000");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSiswa();
  }, []);

  const resetForm = () => {
    setKodeSiswa("");
    setNama("");
    setAlamat("");
    setTgl("");
    setJurusan("");
    setEditingKode(null);
  };

  const handleSubmit = async (e) => {
    e?.preventDefault?.();
    try {
      const payload = { kode_siswa: kodeSiswa, nama_siswa: nama, alamat_siswa: alamat, tgl_siswa: tgl, jurusan_siswa: jurusan };
      if (editingKode) {
        await axios.put(`${API}/${editingKode}`, { nama_siswa: nama, alamat_siswa: alamat, tgl_siswa: tgl, jurusan_siswa: jurusan });
        alert("Data siswa berhasil diperbarui");
      } else {
        await axios.post(API, payload);
        alert("Siswa berhasil ditambahkan");
      }
      resetForm();
      fetchSiswa();
    } catch (err) {
      console.error(err);
      alert("Terjadi error saat menyimpan data");
    }
  };

  const handleEdit = (item) => {
    setEditingKode(item.kode_siswa);
    setKodeSiswa(item.kode_siswa);
    setNama(item.nama_siswa);
    setAlamat(item.alamat_siswa);
    setTgl(item.tgl_siswa);
    setJurusan(item.jurusan_siswa);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (kode) => {
    if (!confirm("Hapus siswa ini?")) return;
    try {
      await axios.delete(`${API}/${kode}`);
      alert("Siswa berhasil dihapus");
      fetchSiswa();
    } catch (err) {
      console.error(err);
      alert("Gagal menghapus siswa");
    }
  };

  return (
    <div className="container py-5">
      <h1 className="mb-4">Daftar Siswa</h1>

      <div className="card mb-4 p-3">
        <form onSubmit={handleSubmit}>
          <div className="row g-2">
            <div className="col-md-4">
              <label className="form-label">Nama</label>
              <input className="form-control" value={nama} onChange={(e)=>setNama(e.target.value)} required />
            </div>
            <div className="col-md-3">
              <label className="form-label">Alamat</label>
              <input className="form-control" value={alamat} onChange={(e)=>setAlamat(e.target.value)} />
            </div>
            <div className="col-md-2">
              <label className="form-label">Tanggal Lahir</label>
              <input type="date" className="form-control" value={tgl} onChange={(e)=>setTgl(e.target.value)} />
            </div>
            <div className="col-md-1">
              <label className="form-label">Jurusan</label>
              <select className="form-control" value={jurusan} onChange={(e)=>setJurusan(e.target.value)}>
                <option value="">Pilih Jurusan</option>
                <option value="RPL">RPL</option>
                <option value="TKJ">TKJ</option>
              </select>
            </div>
          </div>

          <div className="mt-3 d-flex gap-2">
            <button type="submit" className="btn btn-primary">{editingKode ? "Update" : "Simpan"}</button>
            <button type="button" className="btn btn-secondary" onClick={resetForm}>Reset</button>
          </div>
        </form>
      </div>

      <div className="card p-3">
        <h5 className="mb-3">List Siswa</h5>
        {loading ? <p>Loading...</p> : (
          <div className="table-responsive">
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Nama</th>
                  <th>Alamat</th>
                  <th>Tanggal Lahir</th>
                  <th>Jurusan</th>
                </tr>
              </thead>
              <tbody>
                {siswa && siswa.length ? siswa.map((bk)=>(
                  <tr key={bk.kode_siswa}>
                    <td>{bk.kode_siswa}</td>
                    <td>{bk.nama_siswa}</td>
                    <td>{bk.alamat_siswa}</td>
                    <td>{bk.tgl_siswa}</td>
                    <td>{bk.jurusan_siswa}</td>
                    <td>
                      <button className="btn btn-sm btn-outline-primary me-2" onClick={()=>handleEdit(bk)}><FaEdit/></button>
                      <button className="btn btn-sm btn-outline-danger" onClick={()=>handleDelete(bk.kode_siswa)}><FaRegTrashAlt/></button>
                    </td>
                  </tr>
                )) : <tr><td colSpan={6}>Tidak ada data</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
