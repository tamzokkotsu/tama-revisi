import axios from "axios";
import { useEffect, useState } from "react";
import { Modal } from "bootstrap";
import { FaEdit, FaRegTrashAlt } from "react-icons/fa";

export default function DataSiswa() {
    const [siswa, setSiswa] = useState([]);
    const [loading, setLoading] = useState(false);

    const [namaSiswa, setNamaSiswa] = useState("");
    const [alamatSiswa, setAlamatSiswa] = useState("");

    const [editId, setEditId] = useState(null);

    // FETCH DATA
    const fetchData = () => {
        setLoading(true);

        axios
            .get(API)
            .then((response) => {
                setSiswa(response.data);
            })
            .finally(() => setLoading(false));
    };

    useEffect(() => {
        fetchData();
    }, []);

    // TAMBAH DATA
    const handleAdd = () => {
        setLoading(true);

        const payload = {
            nama: namaSiswa,
            alamat: alamatSiswa,
        };

        axios
            .post(API, payload)
            .then((res) => {
                // update local state tanpa reload API
                setSiswa([...siswa, res.data]);
            })
            .finally(() => {
                setLoading(false);
                closeModal();
                resetForm();
            });
    };

    // UPDATE DATA
    const handleUpdate = () => {
        if (!editId) return;

        setLoading(true);

        const payload = {
            nama: namaSiswa,
            alamat: alamatSiswa,
        };

        axios
            .put(`${API}/${editId}`, payload)
            .then(() => {
                // update local state yang di-edit
                setSiswa(
                    siswa.map((item) =>
                        item.id === editId ? { ...item, ...payload } : item
                    )
                );
            })
            .finally(() => {
                setLoading(false);
                closeModal();
                resetForm();
            });
    };

    // BUKA MODAL EDIT
    const handleEdit = (item) => {
        setEditId(item.id);
        setNamaSiswa(item.nama);
        setAlamatSiswa(item.alamat);

        const modal = Modal.getOrCreateInstance(
            document.getElementById("exampleModal")
        );
        modal.show();
    };

    // RESET FORM
    const resetForm = () => {
        setEditId(null);
        setNamaSiswa("");
        setAlamatSiswa("");
    };

    // TUTUP MODAL & HAPUS BACKDROP
    const closeModal = () => {
        const modalEl = document.getElementById("exampleModal");
        const modal = Modal.getOrCreateInstance(modalEl);
        modal.hide();

        document.body.classList.remove("modal-open");
        document.querySelectorAll(".modal-backdrop").forEach((bd) => bd.remove());
    };

    // DELETE DATA
    const handleDelete = (id) => {
        if (!window.confirm("Yakin ingin menghapus data ini?")) return;

        setLoading(true);

        axios
            .delete(`${API}/${id}`)
            .then(() => {
                setSiswa(siswa.filter((item) => item.id !== id));
            })
            .finally(() => setLoading(false));
    };

    return (
        <div className="container mt-4">

            {/* BUTTON TAMBAH */}
            <button
                className="btn btn-success col-12 my-1"
                data-bs-toggle="modal"
                data-bs-target="#exampleModal"
                onClick={resetForm}
            >
                Tambah Data
            </button>

            <hr />

            <div className="card">
                <div className="card-header">Data Pelajar</div>
                <div className="card-body">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>ID</th>
                                <th>NAMA</th>
                                <th>ALAMAT</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>

                        <tbody>
                            {/* LOADING */}
                            {loading && (
                                <tr key="loading">
                                    <td colSpan={6} align="center">
                                        <div className="spinner-border text-primary"></div>
                                    </td>
                                </tr>
                            )}

                            {/* TIDAK ADA DATA */}
                            {!loading && siswa.length === 0 && (
                                <tr key="nodata">
                                    <td colSpan={6} align="center">
                                        Tidak ada data
                                    </td>
                                </tr>
                            )}

                            {/* DATA */}
                            {!loading &&
                                siswa.map((item, index) => (
                                    <tr key={item.id}>
                                        <td>{index + 1}</td>
                                        <td>{item.id}</td>
                                        <td>{item.nama}</td>
                                        <td>{item.alamat}</td>
                                        <td>
                                            <button
                                                className="btn btn-warning me-2"
                                                onClick={() => handleEdit(item)}
                                            >
                                                <FaEdit />
                                            </button>

                                            <button
                                                className="btn btn-danger"
                                                onClick={() => handleDelete(item.id)}
                                            >
                                                <FaRegTrashAlt />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* MODAL FORM */}
            <div className="modal fade" id="exampleModal" tabIndex="-1">
                <div className="modal-dialog">
                    <div className="modal-content">

                        <div className="modal-header">
                            <h1 className="modal-title fs-5">
                                {editId ? "Edit Data Pelajar" : "Tambah Data Pelajar"}
                            </h1>
                            <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                        </div>

                        <div className="modal-body">
                            <form
                                onSubmit={(e) => {
                                    e.preventDefault();
                                    editId ? handleUpdate() : handleAdd();
                                }}
                            >
                                <div className="form-floating mb-3">
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Nama"
                                        value={namaSiswa}
                                        onChange={(e) => setNamaSiswa(e.target.value)}
                                        required
                                    />
                                    <label>Nama</label>
                                </div>

                                <div className="form-floating mb-3">
                                    <textarea
                                        className="form-control"
                                        placeholder="Alamat"
                                        value={alamatSiswa}
                                        onChange={(e) => setAlamatSiswa(e.target.value)}
                                        required
                                    ></textarea>
                                    <label>Alamat</label>
                                </div>

                                <input
                                    type="submit"
                                    className="btn btn-primary col-12"
                                    value={editId ? "Update" : "Simpan"}
                                />
                            </form>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    );
}
