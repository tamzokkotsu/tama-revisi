import { Routes, Route } from "react-router-dom";
import DaftarSiswa from "../pages/DaftarSiswa";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<DaftarSiswa />} />
    </Routes>
  );
}
